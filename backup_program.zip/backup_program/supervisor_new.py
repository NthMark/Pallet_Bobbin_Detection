# supervisor.py
import subprocess, time, sys, os, signal

CMD = [sys.executable, "test_mini.py"]  # hoặc file .exe PyInstaller
BACKOFF_MIN, BACKOFF_MAX = 1.0, 10.0   # giây
MAX_RESTARTS = 5                       # tối đa restart trong cửa sổ thời gian
WINDOW_SEC   = 60                      # cửa sổ 60s

def run_forever():
    restarts = []
    backoff  = BACKOFF_MIN

    while True:
        # dọn lịch sử restart quá cũ
        now = time.time()
        restarts[:] = [t for t in restarts if now - t <= WINDOW_SEC]
        if len(restarts) >= MAX_RESTARTS:
            print("Too many restarts; sleeping 60s to avoid crash-loop")
            time.sleep(60)
            restarts.clear()

        print("Launching:", CMD)
        proc = subprocess.Popen(CMD)

        # Chuyển tín hiệu kill/ctrl+c cho child
        def forward(sig, frame):
            try: proc.send_signal(sig)
            except Exception: pass
        signal.signal(signal.SIGINT, forward)
        signal.signal(signal.SIGTERM, forward)

        ret = proc.wait()
        print("Process exited with code:", ret)

        # Nếu thoát bình thường (0), thì dừng luôn
        if ret == 0:
            break

        # Ghi nhận restart
        restarts.append(time.time())
        time.sleep(backoff)
        backoff = min(backoff * 2.0, BACKOFF_MAX)

if __name__ == "__main__":
    run_forever()
